using Godot;
using System;

public class InventoryButton : Button
{
    public Item inventoryItem;
    private TextureRect icon;
    private Label quantityLabel;
    private bool hasItem;
    private int index;
    [Export]
    public Texture bild { get; set; }
    public override void _Ready()
    {
        icon = GetNode<TextureRect>("TextureRect");
        quantityLabel = GetNode<Label>("Label");

    }
public override void _Process(float delta)
{
    
}
    public void UpdateItem(Item item, int index)
    {
        this.index= index;
        inventoryItem = item;
        if(item == null)
        {
            icon.Texture = null;
            quantityLabel.Text = string.Empty;
        }
        else
        {
            icon.Texture = item.Icon;
            quantityLabel.Text = item.quantity.ToString();
        }
    }
}
