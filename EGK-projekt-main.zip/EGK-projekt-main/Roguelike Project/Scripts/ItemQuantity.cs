using Godot;
using System;

public class ItemQuantity : Label
{
    private static int quantity2 = 0;
    public override void _Ready()
    {
        var item_quantity = GetNode<Control>("ItemSlot/ItemQuantity");
    }
    public static void set_Quantity(int quantity)
    {
        quantity2 = quantity;
    }
    public static string get_Quantity()
    {
        return quantity2.ToString();
    }
    public override void _Process(float delta)
    {
        this.Text = ItemQuantity.get_Quantity();
    }
}
