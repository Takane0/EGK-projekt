using Godot;
using System;
using System.Collections.Generic;
using System.Linq;

public class InventoryOverall : Control
{
    private GridContainer gridContainer;
    private GridContainer gridContainer2;
#pragma warning disable 649
    [Export]
    public PackedScene inventoryButton;
#pragma warning restore 649
    private string itemButtonpath = "res://UI/inventory_Button.tscn";
    private static bool visibil = false;

    public InventoryButton GrabbedObject { get; set; }
    public InventoryButton HoverOverButton { get; set; }
    private Vector2 lastMouseClickedPos;
    private bool WesternGameDev = true;
    private bool WesternGameDev2 = false;
    

    private List<Item> items= new List<Item>(27);
    public override void _Ready()
    {
        gridContainer = GetNode<GridContainer>("Container/GridContainer");
        GetNode<GridContainer>("Container/GridContainer").Hide();
        GetNode<Button>("AddButtom").Hide();
        GetNode<Button>("RemoveButton").Hide();
        inventoryButton = ResourceLoader.Load<PackedScene>(itemButtonpath);
        populateButtons();
    }
    public override void _Process(float delta)
    {
        GetNode<Area2D>("MouseArea2d").Position = GetTree().Root.GetMousePosition();
        if(HoverOverButton!= null)
        {
            if(Input.IsActionJustPressed("Throw"))
            {
                GrabbedObject = HoverOverButton;
                lastMouseClickedPos = GetTree().Root.GetMousePosition();
            }
            if (lastMouseClickedPos.DistanceTo(GetTree().Root.GetMousePosition()) > 2)
            {
                //if (Input.IsActionJustPressed("Throw"))
                    if (Input.IsActionPressed("Throw") && WesternGameDev)
                {
                    GrabbedObject = HoverOverButton;
                    InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
                    button.Show();
                    Single.Set_PlayerCurrentHp(10000000);
                        button.UpdateItem(GrabbedObject.inventoryItem, 0);
                    WesternGameDev = false;
                    WesternGameDev2 = true;
                }
                //if(Input.IsActionJustReleased("Throw"))
                if (Input.IsActionPressed("Throw") == false && WesternGameDev2)
                {
                    swapButtons(GrabbedObject, HoverOverButton);
                    InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
                    button.Hide();
                    WesternGameDev = true;
                    WesternGameDev2 = false;
                }
            }
        }
    }
    private void swapButtons(InventoryButton button1, InventoryButton button2)
    {
            int buttonindex = button1.GetIndex();
            int button2index = button2.GetIndex();
            Single.Set_PlayerCurrentHp(10000);
            gridContainer.MoveChild(button1, button2index);
            gridContainer.MoveChild(button2, buttonindex);
    }
    public override void _UnhandledInput(InputEvent @event)
    {
        if (@event.IsActionPressed("press_E") && GetNode<GridContainer>("Container/GridContainer").Visible == false && visibil == false)
        {
            visibil= true;
            GetNode<GridContainer>("Container/GridContainer").Show();
            GetNode<Button>("AddButtom").Show();
            GetNode<Button>("RemoveButton").Show();
            Player.set_Mouse(true);
        }
        if (@event.IsActionPressed("press_E") && GetNode<GridContainer>("Container/GridContainer").Visible && visibil == false)
        {
            visibil = true;
            GetNode<GridContainer>("Container/GridContainer").Hide();
            GetNode<Button>("AddButtom").Hide();
            GetNode<Button>("RemoveButton").Hide();
            Player.set_Mouse(false);
        }
        visibil= false;
    }
    private void populateButtons()
    {
        for (int i = 0; i < 28; i++)
        {
            InventoryButton currentImventoryButton = inventoryButton.Instance<InventoryButton>();
            gridContainer.AddChild(currentImventoryButton);
        }
    }
    public void Add(Item item) 
    {   Item currentItem = item.Copy();
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].ID == currentItem.ID && items[i].quantity != items[i].StackSize)
            {
                if (items[i].quantity + currentItem.quantity > items[i].StackSize)  
                {
                    items[i].quantity = currentItem.StackSize;
                    currentItem.quantity = -(currentItem.quantity - items[i].StackSize);
                    UpdateButton(i);
                }
                else
                {
                    items[i].quantity += currentItem.quantity;
                    currentItem.quantity = 0;
                    UpdateButton(i);
                }
            }
        }
        if (currentItem.quantity > 0)
        {
            if (currentItem.quantity < currentItem.StackSize)
            { currentItem.Icon = Get_Texture(item);
            items.Add(currentItem);
            UpdateButton(items.Count - 1);
            }
            else
            {
                currentItem.Icon = Get_Texture(item);
                Item tempItem = currentItem.Copy();
                tempItem.quantity = currentItem.StackSize;
                items.Add(tempItem);
                UpdateButton(items.Count - 1);
                currentItem.quantity -= currentItem.StackSize;
                Add(currentItem);
            }
        }
    }
    public Texture Get_Texture(Item item)
    {
        return ResourceLoader.Load<Texture>("res://icon.png");
    }
    public void UpdateButton(int index)
    {
        if(index < 28)
            if(items.ElementAtOrDefault(index) != null) 
            gridContainer.GetChild<InventoryButton>(index).UpdateItem(items[index], index);
            else
                gridContainer.GetChild<InventoryButton>(index).UpdateItem(null, index);
    }
    public void _on_AddButtom_button_down()
    {
        Item test = new Item();
            float randamAss= (Single.get_RandomFloat(1,5));
        test.quantity = Convert.ToInt32(randamAss);
        test.IsStackable = true;
        test.StackSize = 7;
        Add(test);
    }
    public void _on_RemoveButton_button_down()
    {
        Item fest = new Item();
        fest.Icon = Get_Texture(fest);
        fest.StackSize = 5;
        fest.IsStackable = true;
        fest.quantity = 15;
        remove(fest);
    }
    public void remove(Item item)
    {
            Item currentItem = item.Copy();
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].ID == currentItem.ID)
                {
                    if (items[i].quantity - currentItem.quantity < 0)
                    {
                    currentItem.quantity -= items[i].quantity;
                    items[i].quantity = 0;
                        UpdateButton(i);
                    }
                    else
                    {
                        items[i].quantity -= currentItem.quantity;
                        currentItem.quantity = 0;
                        UpdateButton(i);
                    }
                }
                if(currentItem.quantity <= 0)
            {
                break;
            }
            }

            items.RemoveAll(x => x.quantity <= 0);
        if (currentItem.quantity > 0)
        {
            remove(currentItem);
        }
        reflowButtons();
        }
    private void reflowButtons()
    {
        for (int i = 0; i < 27; i++)
        {
            UpdateButton(i);
        }
    }
    public static void set_visibil()
    {
        visibil = true;
    }
    public static void set_unvisibil()
    {
        visibil= false;
    }
    public static bool get_visibility()
    {
        if(visibil == true)
            return true;
        else return false;
    }
    public void _on_MouseArea2d_area_entered(Area2D area)
    {
        Control button = area.GetParent<Control>();
        if(button is InventoryButton)
        {
            HoverOverButton = (InventoryButton)button;
        }
    }
    public void _on_MouseArea2d_area_exited(Area2D area) { HoverOverButton = null; }
}