using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;

public class InventoryOverall : Control
{
    private GridContainer gridContainer;
    private GridContainer gridContainer2;
#pragma warning disable 649
    [Export]
    public PackedScene inventoryButton;
#pragma warning restore 649
    private string itemButtonpath = "res://UI/inventory_Button.tscn";
    private static bool visibil = false;
    private static bool visibil2 = false;   
    public InventoryButton GrabbedObject { get; set; }
    public InventoryButton HoverOverButton { get; set; }
    private Vector2 lastMouseClickedPos;
    private int EquippedItem = 0;
    private bool WesternGameDev = true;
    private bool WesternGameDev2 = false;   
    private bool OverTrash = false;
    private static Item export;
    private bool change = true;

    private List<Item> items= new List<Item>(27);
    public override void _Ready()
    {
        gridContainer = GetNode<GridContainer>("Container/GridContainer");
        GetNode<GridContainer>("Container/GridContainer").Show();
        GetNode<Button>("AddButtom").Hide();
        GetNode<Panel>("Panel").Hide();
        inventoryButton = ResourceLoader.Load<PackedScene>(itemButtonpath);
        populateButtons();
        HideInventory();
    }
    public override void _Process(float delta)
    {
        if(export != null) { Add(export); export = null; }
        if(change)
        {
            Player.set_HeldItemID(gridContainer.GetChild<InventoryButton>(EquippedItem).get_ID()); change = false;
        }
        GetNode<Area2D>("MouseArea2d").Position = GetTree().Root.GetMousePosition();
        if(HoverOverButton!= null && visibil2 == true)
        {
            if(Input.IsActionJustPressed("Throw"))
            {
                GrabbedObject = HoverOverButton;
                lastMouseClickedPos = GetTree().Root.GetMousePosition();
                WesternGameDev = true;
            }
            if (lastMouseClickedPos.DistanceTo(GetTree().Root.GetMousePosition()) > 0 && GrabbedObject != null)
            {
                if (Input.IsActionPressed("Throw") && WesternGameDev == true)
                {
                    //GrabbedObject = HoverOverButton;
                    InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
                    button.Show();
                    button.UpdateItem(GrabbedObject.inventoryItem, 0);
                    WesternGameDev = false;
                    WesternGameDev2 = true;
                }
                if (Input.IsActionPressed("Throw")== false && WesternGameDev2 == true)
                {
                    if(OverTrash == true)
                    {
                        Single.Set_PlayerCurrentHp(34786348);
                        DeleteButton(GrabbedObject);
                    }
                    else
                    {
                        swapButtons(GrabbedObject, HoverOverButton);
                        InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
                        button.Hide();
                    }
                    WesternGameDev2 = false;
                }
            }
        }
        if( HoverOverButton== null && OverTrash && Input.IsActionPressed("Throw") == false && GrabbedObject != null)
        {
            DeleteButton(GrabbedObject);
            InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
            button.Hide();
        }
        if (Input.IsActionJustReleased("ScrollDown"))
        {
            highlightButtons(false);
        }
        if (Input.IsActionJustReleased("ScrollUp"))
        {
            highlightButtons(true);
        }

    }
    public static void Set_export(Item item)
    {
        export = item;
    }
    public static Item Get_export()
    {
        return export;

    }
    public void DeleteButton (InventoryButton inventoryButton) 
    {
        items.Remove(inventoryButton.inventoryItem);
        reflowButtons();
    }
    private void highlightButtons(bool left)
    {
        if (left)
        {
            if (GetNode<Label>("HighLight").MarginLeft > 399)
            {
                GetNode<Label>("HighLight").MarginLeft = GetNode<Label>("HighLight").MarginLeft - 84;
            }
            else
            {
                GetNode<Label>("HighLight").MarginLeft = 903;
            }
            }
        else
        {
            if (GetNode<Label>("HighLight").MarginLeft < 903)
            {
                GetNode<Label>("HighLight").MarginLeft = GetNode<Label>("HighLight").MarginLeft + 84;
            }
            else
            {
                GetNode<Label>("HighLight").MarginLeft = 399;
            }
        }
        EquippedItem = 6-(Convert.ToInt32(GetNode<Label>("HighLight").MarginLeft) - 399) / 84;
        change = true;
    }
    private void swapButtons(InventoryButton button1, InventoryButton button2)
    {
            int buttonindex = button1.GetIndex();
            int button2index = button2.GetIndex();
            gridContainer.MoveChild(button1, button2index);
            gridContainer.MoveChild(button2, buttonindex);
        HoverOverButton = null;
        GrabbedObject= null;    
    }
    public void ShowInventory()
    {
        //for (int Hotbar = 27; Hotbar > 6; Hotbar--)
        for (int Hotbar = 7 ; Hotbar < 28; Hotbar++)
        {
            gridContainer.GetChild<InventoryButton>(Hotbar).Show();
        }
    }
    public void HideInventory()
    {
        //for (int Hotbar = 27; Hotbar > 6; Hotbar--)
            for (int Hotbar = 7; Hotbar < 28; Hotbar++)
        {
            gridContainer.GetChild<InventoryButton>(Hotbar).Hide();
        }
    }

    public override void _UnhandledInput(InputEvent @event)
    {
        if (@event.IsActionPressed("press_E") && GetNode<Panel>("Panel").Visible == false && visibil == false)
        {
            visibil = true;
            visibil2 = true;
            GetNode<Panel>("Panel").Show();
            GetNode<Button>("AddButtom").Show();
            ShowInventory();
            Player.set_Mouse(true);
        }
        if (@event.IsActionPressed("press_E") && GetNode<Panel>("Panel").Visible && visibil == false)
        {
            visibil = true;
            visibil2 = false;
            GetNode<Panel>("Panel").Hide();
            GetNode<Button>("AddButtom").Hide();
            HideInventory();
            InventoryButton button = GetNode<Area2D>("MouseArea2d").GetNode<InventoryButton>("InventoryButton");
            button.Hide();
            WesternGameDev = true;
            Player.set_Mouse(false);
        }

        visibil = false;
    }
    private void populateButtons()
    {
        for (int i = 0; i <28; i++)
        {
            InventoryButton currentInventoryButton = inventoryButton.Instance<InventoryButton>();
            gridContainer.AddChild(currentInventoryButton);
        }
    }
    public void Add(Item item) 
    {   Item currentItem = item.Copy();
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].ID == currentItem.ID && items[i].quantity != items[i].StackSize)
            {
                if (items[i].quantity + currentItem.quantity > items[i].StackSize)  
                {
                    items[i].quantity = currentItem.StackSize;
                    currentItem.quantity = -(currentItem.quantity - items[i].StackSize);
                    UpdateButton(i);
                }
                else
                {
                    items[i].quantity += currentItem.quantity;
                    currentItem.quantity = 0;
                    UpdateButton(i);
                }
            }
        }
        if (currentItem.quantity > 0)
        {
            if (currentItem.quantity < currentItem.StackSize)
            { currentItem.Icon = Get_Texture(item);
            items.Add(currentItem);
            UpdateButton(items.Count - 1);
            }
            else
            {
                currentItem.Icon = Item.Get_Texture(item.ID);
                Item tempItem = currentItem.Copy();
                tempItem.quantity = currentItem.StackSize;
                items.Add(tempItem);
                UpdateButton(items.Count - 1);
                currentItem.quantity -= currentItem.StackSize;
                Add(currentItem);
            }
        }
        change = true;
    }
    public Texture Get_Texture(Item item)
    {
        
        return ResourceLoader.Load<Texture>("res://Video-Game-Gold-Coin-PNG.png");
    }
    public void UpdateButton(int index)
    {
        if(index < 28)
            if(items.ElementAtOrDefault(index) != null) 
            gridContainer.GetChild<InventoryButton>(index).UpdateItem(items[index], index);
            else
                gridContainer.GetChild<InventoryButton>(index).UpdateItem(null, index);
    }
    public void _on_AddButtom_button_down()
    {
        Item test = new Item();
            float randamAss= (Single.get_RandomFloat(1,5));
        test.quantity = Convert.ToInt32(randamAss);
        test.IsStackable = true;
        test.StackSize = 7;
        test.ID = 1;
        Add(test);
    }
    public void remove(Item item)
    {
            Item currentItem = item.Copy();
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].ID == currentItem.ID)
                {
                    if (items[i].quantity - currentItem.quantity < 0)
                    {
                    currentItem.quantity -= items[i].quantity;
                    items[i].quantity = 0;
                        UpdateButton(i);
                    }
                    else
                    {
                        items[i].quantity -= currentItem.quantity;
                        currentItem.quantity = 0;
                        UpdateButton(i);
                    }
                }
                if(currentItem.quantity <= 0)
            {
                break;
            }
            }

            items.RemoveAll(x => x.quantity <= 0);
        if (currentItem.quantity > 0)
        {
            remove(currentItem);
        }
        reflowButtons();
        }
    private void reflowButtons()
    {
        for (int i = 0; i < 27; i++)
        {
            UpdateButton(i);
        }
    }
    public static void set_visibil()
    {
        visibil = true;
    }
    public static void set_unvisibil()
    {
        visibil= false;
    }
    public static bool get_visibility()
    {
        if(visibil == true)
            return true;
        else return false;
    }
    public void _on_MouseArea2d_area_entered(Area2D area)
    {
        Control button = area.GetParent<Control>();
        if(button is InventoryButton)
        {
            HoverOverButton = (InventoryButton)button;
        }
    }
    public void _on_MouseArea2d_area_exited(Area2D area) { HoverOverButton = null; }

    public void _on_TrashArea2D_area_entered(Area2D area) 
    { OverTrash = true;
    }
    public void _on_TrashArea2D_area_exited(Area2D area) 
    { 
        OverTrash = false; 
    }

}