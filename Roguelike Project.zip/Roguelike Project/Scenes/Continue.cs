using Godot;
using System;

public class Continue : Button
{
    public override void _Ready()
    {
        
    }

    public override void _Process(float delta)
    {

    }
}
