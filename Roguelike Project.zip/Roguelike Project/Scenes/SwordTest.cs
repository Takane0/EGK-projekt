using Godot;
using System;

public class SwordTest : KinematicBody
{
    [Export]
    public  int ID { get; set; }
    [Export]
    public  string Name { get; set; }
    [Export]
    public  string ResourcePath { get; set; }
    [Export]
    public  int StackSize { get; set; }
    [Export]
    public  Texture Icon { get; set; }
    [Export]
    public  int quantity { get; set; }

    [Export]
    public  bool IsStackable { get; set; }
    public MeshInstance ItemMesh { get; set; }
    public override void _Ready()
    {

    }

    private void Die()
    {
        QueueFree();
    }
    public void _on_Area_body_entered(Node body)
    {
        PickUp();
    }
    private void PickUp() 
    {
        Item item = new Item();
        item.ID = ID;
        item.Name = Name;
        item.ResourcePath = ResourcePath;
        item.StackSize = StackSize;
        item.Icon = Icon;
        item.quantity = quantity;
        item.IsStackable= IsStackable;
        InventoryOverall.Set_export(item);
        Die();
    }
}
