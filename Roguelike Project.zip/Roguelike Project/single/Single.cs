using Godot;
using System;

public class Single : Node
{
    private string PlayerName;
    private static double PlayerCurrentHp = 100;
    private static double PlayerMaxHp = 100;
    private static double PlayerCurrentMp;
    private static double PlayerMaxMp;
    private static double PlayerExp;
    private static double PlayerMaxExp;
    private static double PlayerLevel;
    private static double PlayerGold;
    private static double PlayerArmor;
    private static double PlayerAttackDamage;
    private static double PlayerMagicDamage;
    private static double PlayerDamageReduction;
    private static double PlayerLuck;
    private static double PlayerLifeSteal;
    private static double PlayerCritRate;
    private static double PlayerCritDamage;
    private static double PlayerSkillpoints;
    private static double WorldLevel;
    private static double WorldDifficulty;
    public override void _Ready()
    {

    }
    public void Set_PlayerName(string Set_PlayerName)
    {PlayerName = Set_PlayerName;}
    public string Get_PlayerName()
    { return PlayerName; }
    public static void Set_PlayerCurrentHp(double Set_PlayerCurrentHp)
    { PlayerCurrentHp = Set_PlayerCurrentHp;
    }
    public static double Get_PlayerCurrentHp()
    { return PlayerCurrentHp; }
    public void Set_PlayerMaxHp(double Set_PlayerMaxHp)
    { PlayerMaxHp = Set_PlayerMaxHp; }
    public static double Get_PlayerMaxHp()
    { return PlayerMaxHp; }
    public static void Set_PlayerCurrentMp(double Set_PlayerCurrentMp)
    { PlayerCurrentMp = Set_PlayerCurrentMp; }
    public static double Get_PlayerCurrentMp()
    { return PlayerCurrentMp; }
    public static void Set_PlayerMaxMp(double Set_PlayerMaxMp)
    { PlayerMaxMp = Set_PlayerMaxMp; }
    public static double Get_PlayerMaxMp()
    { return PlayerMaxMp; }
    public static void Set_PlayerExp(double Set_PlayerExp)
    { PlayerExp = Set_PlayerExp; }
    public static double Get_PlayerExp()
    { return PlayerExp; }
    public static void Set_PlayerMaxExp(double Set_PlayerMaxExp)
    { PlayerMaxExp = Set_PlayerMaxExp; }
    public static double Get_PlayerMaxExp()
    { return PlayerMaxExp; }
    public static void Set_PlayerLevel(double Set_PlayerLevel)
    { PlayerLevel = Set_PlayerLevel; }
    public static double Get_PlayerLevel()
    { return PlayerLevel; }
    public static void Set_PlayerGold(double Set_PlayerGold)
    { PlayerGold = Set_PlayerGold; }
    public static double Get_PlayerGold()
    { return PlayerGold; }
    public static void Set_PlayerLuck(double Set_PlayerLuck)
    { PlayerLuck = Set_PlayerLuck; }
    public static double Get_PlayerLuck()
    { return PlayerLuck; }
    public static void Set_PlayerArmor(double Set_PlayerArmor)
    { PlayerArmor = Set_PlayerArmor; }
    public static double Get_PlayerArmor()
    { return PlayerArmor; }
    public static void Set_PlayerMagicDamage(double Set_PlayerMagicDamage)
    { PlayerMagicDamage = Set_PlayerMagicDamage; }
    public static double Get_PlayerMagicDamage()
    { return PlayerMagicDamage; }
    public static void Set_PlayerAttackDamage(double Set_PlayerAttackDamage)
    { PlayerAttackDamage = Set_PlayerAttackDamage; }
    public static double Get_PlayerAttackDamage()
    { return PlayerAttackDamage; }
    public static void Set_PlayerLifeSteal(double Set_PlayerLifeSteal)
    { PlayerLifeSteal = Set_PlayerLifeSteal; }
    public static double Get_PlayerLifeSteal()
    { return PlayerLifeSteal; }
    public static void Set_PlayerCritDamage(double Set_PlayerCritDamage)
    { PlayerCritDamage = Set_PlayerCritDamage; }
    public static double Get_PlayerCritDamage()
    { return PlayerCritDamage; }
    public static void Set_PlayerCritRate(double Set_PlayerCritRate)
    { PlayerCritRate = Set_PlayerCritRate; }
    public static double Get_PlayerCritRate()
    { return PlayerCritRate; }
    public static void Set_WorldLevel(double Set_WorldLevel)
    { WorldLevel = Set_WorldLevel; }
    public static double Get_WorldLevel()
    { return WorldLevel; }
    public static double Calc_Dmg(double currentHpfromtaker, double dmgfrommaker)
    {
        return 1;
        //return currentHpfromtaker -= dmgfrommaker;
    }
    public static float get_RandomFloat(int smallest, int biggest)
    {
        Random rng = new Random();
        double RandomNumber = rng.Next(smallest, biggest);
        return (float)RandomNumber;
    }
    public static float get_RandomInt(int smallest, int biggest)
    {
        Random rng = new Random();
        double RandomNumber = rng.Next(smallest, biggest);
        return (int)RandomNumber;
    }

}
