using Godot;
using System;
public class Item : Resource
{
    [Export]
    public int ID { get; set; }
    [Export]
    public string Name { get; set; }
    [Export]
    public string ResourcePath { get; set; }
    [Export]
    public int StackSize { get; set; }
    [Export]
    public Texture Icon { get; set; }
    [Export]
    public int quantity { get; set; }

    [Export]
    public bool IsStackable { get; set; }

    public MeshInstance ItemMesh { get; set; }

    public Item Copy() => MemberwiseClone() as Item;

    public static Item GenerateItem(int id)
    {
        Item item = new Item();
        switch (id)
        {
            case 0:
                item.ID = 0;
                item.Name = "Schwert";
                item.StackSize= 1;
                item.Icon = Get_Texture(id);
                item.quantity = 1;
                item.IsStackable = false;
                break;
        }
        return item;
    }
    public static Texture Get_Texture(int id)
    {
        switch (id)
        {
            case 0:
                return ResourceLoader.Load<Texture>("res://image/tcg-alt-art-cartesia-leak-v0-xjb6fza7kmxc1.webp");
            case 1:
                return ResourceLoader.Load<Texture>("res://Video-Game-Gold-Coin-PNG.png");
            case 2:
                return ResourceLoader.Load<Texture>("res://Video-Game-Gold-Coin-PNG.png");
            case 3:
                return ResourceLoader.Load<Texture>("res://Video-Game-Gold-Coin-PNG.png");
            case 4:
                return ResourceLoader.Load<Texture>("res://Video-Game-Gold-Coin-PNG.png");
        }
        return null;
    }
}
