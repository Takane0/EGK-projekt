using Godot;
using System;

public class InventoryButton : Button
{
    public Item inventoryItem;
    private TextureRect icon;
    private Label quantityLabel;
    private bool hasItem;
    private int index;
    private int ID = 99;
    [Export]
    public Texture bild { get; set; }
    public override void _Ready()
    {
        icon = GetNode<TextureRect>("TextureRect");
        quantityLabel = GetNode<Label>("Label");
        ID = 99;

    }
public override void _Process(float delta)
{
    
}
    public void UpdateItem(Item item, int index)
    {
        this.index= index;
        inventoryItem = item;
        if(item == null)
        {
            icon.Texture = null;
            quantityLabel.Text = string.Empty;
            ID = 99;
        }
        else
        {
            ID = item.ID;
            icon.Texture = item.Icon;
            if(item.IsStackable == true)
            quantityLabel.Text = item.quantity.ToString();
            else
            {
                quantityLabel.Text = null;
            }
        }
    }
    public int get_ID()
    {
        return ID;
    }
}
