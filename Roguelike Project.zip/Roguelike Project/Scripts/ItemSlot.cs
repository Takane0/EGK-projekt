using Godot;
using System;

public class ItemSlot : ColorRect
{
    public override void _Ready()
    {
        ItemIcon item_icon = new ItemIcon();
        ItemQuantity item_quantity = new ItemQuantity();
    }
    public void display_item (ItemSlot item)
    {
        ItemIcon item_icon = new ItemIcon();
        ItemQuantity item_quantity = new ItemQuantity();
        if (item == null)
        {
            item_icon = null;
            ItemQuantity.set_Quantity(0);
           }

        else
        {
            //item_icon = GetNode<Control>(LoadImage(item.Name));
        }
    }
    public string LoadImage(string Item)
    {
        if (Item == "SwordTest")
            return ".";
        else
            return null;
    }
}
