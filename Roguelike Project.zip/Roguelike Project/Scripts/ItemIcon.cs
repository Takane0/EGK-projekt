using Godot;
using System;

public class ItemIcon : TextureRect
{
    public override void _Ready()
    {
        var item_icon = GetNode<Control>("ItemSlot/ItemIcon");
    }
}
